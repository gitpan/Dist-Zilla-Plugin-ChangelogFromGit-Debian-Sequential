  use strict;
  use warnings;
  package {{$name}};

  1;
